import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'app.dart';
import 'config/app_environment.dart';

void main() {
  if (kDebugMode) {
    debugPrint('GuangHeng Environment: ${AppEnvironmentConfig.current.name}');
    debugPrint('GuangHeng API: ${AppEnvironmentConfig.baseUrl}');
  }
  runApp(const GuangHengApp());
}
