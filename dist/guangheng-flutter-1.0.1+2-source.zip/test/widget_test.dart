import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:guangheng/app.dart';
import 'package:guangheng/models/backend_models.dart';
import 'package:guangheng/repositories/backend_repository.dart';
import 'package:guangheng/services/backend_api_client.dart';

class TestBackendRepository extends BackendRepository {
  TestBackendRepository() : super(BackendApiClient(baseUrl: 'http://test'));

  String selectedAutonomyLevel = 'CONFIRM';

  @override
  Future<String> updateAutonomyLevel(String level) async {
    selectedAutonomyLevel = level;
    return level;
  }
}

BackendSnapshot snapshot() => BackendSnapshot(
  energy: const EnergyState(
    solarW: 1200,
    homeLoadW: 900,
    chargeW: 300,
    soc: 68,
    batteryStatus: 'charging',
    sourceMode: 'simulator',
  ),
  today: EnergyToday(
    available: true,
    summary: const EnergyTodaySummary(
      generationKwh: 8.4,
      consumptionKwh: 6.7,
      savingsCny: 2.9,
      generationChangePercent: 12,
      consumptionChangePercent: -8,
      savingsChangePercent: 6,
      tariffPricePerKwh: .54,
    ),
    flow: List.generate(
      12,
      (hour) => EnergyFlowPoint(
        time: DateTime(2026, 9, 20, hour),
        hour: hour,
        solarPowerW: hour * 120,
        homeLoadW: 900,
        coveragePercent: 100,
      ),
    ),
    coveragePercent: 100,
  ),
  schedule: EnergySchedule(
    available: true,
    points: List.generate(
      24,
      (hour) => EnergySchedulePoint(
        time: DateTime(2026, 9, 20, hour),
        hour: hour,
        solarPowerW: hour >= 7 && hour <= 18
            ? 3200 * (1 - (hour - 12).abs() / 7).clamp(0, 1)
            : 0,
        loadPowerW: 1800 + (hour >= 18 ? 900 : 0),
        netPowerW: 0,
        action: hour < 7
            ? 'PRESERVE_RESERVE'
            : hour < 17
            ? 'STORE_SURPLUS'
            : 'COVER_DEFICIT',
        confidence: 'MEDIUM',
      ),
    ),
    strategy: 'BACKUP',
    advisoryOnly: true,
    executable: false,
    projectedSolarKwh: 18.4,
    projectedLoadKwh: 15.2,
  ),
  report: EnergyReport(
    available: true,
    tariffPricePerKwh: .54,
    carbonFactorKgPerKwh: .6096,
    carbonProvider: 'MEE_NBS',
    carbonReferenceYear: 2023,
    periods: {
      for (final name in ['today', 'week', 'month'])
        name: EnergyReportPeriod(
          metrics: const EnergyReportMetrics(
            consumptionKwh: 6.7,
            generationKwh: 8.4,
            gridImportKwh: 2.1,
            solarSelfUsePercent: 72,
            referenceBaselineCostCny: 3.62,
            actualGridCostCny: 1.13,
            savingsCny: 2.49,
            savingsPercent: 68.8,
            carbonReductionKg: 2.8,
          ),
          daily: [
            EnergyReportDailyPoint(
              date: DateTime(2026, 9, 20),
              actualGridCostCny: 1.13,
              savingsCny: 2.49,
              carbonReductionKg: 2.8,
            ),
          ],
          coveragePercent: 100,
        ),
    },
  ),
  weather: const WeatherContext(condition: 'partly_cloudy', temperature: 25),
  solar: const ForecastData(method: 'solar-test', points: [], next24h: null),
  load: const ForecastData(method: 'load-test', points: [], next24h: 12),
  strategy: const StrategyState('BACKUP', backupReserveTarget: 35),
  autonomy: const AutonomyStatus(
    agentState: 'MONITORING',
    enabled: false,
    unreadCount: 0,
    latestDecision: DecisionSummary(
      strategy: 'BACKUP',
      version: 'v2',
      confidence: 'LOW',
      currentValue: 80,
      targetValue: 80,
      actionRequired: false,
      reasonCode: 'TARGET_ALREADY_SATISFIED',
    ),
  ),
  decisions: const [
    DecisionRun(
      id: 1,
      status: 'COMPLETED',
      strategy: 'BACKUP',
      currentValue: 80,
      targetValue: 80,
      reasonCode: 'TARGET_ALREADY_SATISFIED',
      confidence: 'LOW',
      actionRequired: false,
    ),
  ],
  station: StationSummary(
    available: true,
    online: true,
    dataQuality: 'good',
    coveragePercent: 100,
    deviceId: 1,
    displayName: '家庭能源中心',
    sourceMode: 'simulator',
    observedAt: DateTime(2026, 9, 20, 12),
    nodes: const [
      StationNode(
        key: 'solar',
        label: '光伏',
        available: true,
        direction: 'out',
        powerW: 1200,
      ),
      StationNode(
        key: 'home',
        label: '家庭',
        available: true,
        direction: 'in',
        powerW: 900,
      ),
      StationNode(
        key: 'battery',
        label: '储能',
        available: true,
        direction: 'in',
        powerW: 300,
      ),
      StationNode(
        key: 'grid',
        label: '电网',
        available: true,
        direction: 'idle',
        powerW: 0,
      ),
    ],
  ),
  batteryInsight: const BatteryInsight(
    available: true,
    assumptions: ['备电时长按当前家庭负载估算', '关键负载尚未配置'],
    soc: 68,
    capacityKwh: 10,
    currentEnergyKwh: 6.8,
    reservePercent: 35,
    protectedEnergyKwh: 3.5,
    usableEnergyKwh: 5.8,
    homeLoadW: 900,
    wholeHomeHours: 5.9,
    status: 'Charging',
  ),
  devices: const [
    DiscoveredDevice(
      deviceId: 'solix-test',
      model: 'Anker SOLIX Solarbank 4 E5000 Pro',
      online: true,
      sourceMode: 'simulator',
      firmware: 'SIM-1.0.0',
      telemetry: [
        DeviceCapability(
          name: 'battery_soc',
          access: 'read',
          available: true,
          value: 68,
          unit: '%',
        ),
      ],
      controls: [
        DeviceCapability(
          name: 'backup_reserve',
          access: 'read_write',
          available: true,
          value: 35,
          unit: '%',
          verified: true,
        ),
      ],
    ),
  ],
);

Future<void> pumpAt(WidgetTester tester, double width) async {
  tester.view.physicalSize = Size(width, 900);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  await tester.pumpWidget(
    GuangHengApp(enableInteractive3d: false, initialData: snapshot()),
  );
  await tester.pumpAndSettle();
}

void main() {
  for (final width in [360.0, 390.0, 430.0]) {
    testWidgets('responsive real-data pages at ${width.toInt()}dp', (
      tester,
    ) async {
      await pumpAt(tester, width);
      expect(find.text('光伏'), findsOneWidget);
      expect(find.text('运行中'), findsOneWidget);
      await tester.tap(find.text('策略'));
      await tester.pumpAndSettle();
      expect(find.text('备电优先'), findsWidgets);
      expect(find.text('当前策略'), findsOneWidget);
      expect(find.text('24 小时计划'), findsOneWidget);
      expect(find.text('今日调度'), findsOneWidget);
      expect(find.text('备用 SOC 35%'), findsOneWidget);
      expect(find.text('电池充电'), findsOneWidget);
      expect(find.text('光伏供电'), findsOneWidget);
      expect(find.text('电池放电'), findsOneWidget);
      expect(find.text('备用时段'), findsOneWidget);
      final scheduleBar = find.byKey(const Key('schedule-segment-bar'));
      expect(scheduleBar, findsOneWidget);
      expect(tester.getSize(scheduleBar).height, 32);
      await tester.drag(find.byType(ListView), const Offset(0, -1400));
      await tester.pumpAndSettle();
      expect(find.text('确认模式'), findsWidgets);
      await tester.tap(find.text('报表'));
      await tester.pumpAndSettle();
      expect(find.text('参考基线 vs 实际购电'), findsOneWidget);
      await tester.drag(find.byType(ListView), const Offset(0, -1800));
      await tester.pumpAndSettle();
      final savingChart = find.byKey(const Key('saving-trend-chart'));
      expect(savingChart, findsOneWidget);
      expect(tester.getSize(savingChart).height, 184);
      expect(find.text('相比参考基线，本期节省 69%'), findsOneWidget);
      expect(find.text('预计减少约 2.80 kg 碳排放'), findsOneWidget);
      expect(find.text('光衡完成能源分析'), findsOneWidget);
      await tester.tap(find.text('设备'));
      await tester.pumpAndSettle();
      expect(find.text('Anker SOLIX Solarbank 4 E5000 Pro'), findsOneWidget);
      expect(find.text('1 台设备 · 1 台在线 · 1 项控制已验证'), findsOneWidget);
    });
  }

  testWidgets('autonomy level persists and full access requires confirmation', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    final repository = TestBackendRepository();
    await tester.pumpWidget(
      GuangHengApp(
        enableInteractive3d: false,
        initialData: snapshot(),
        repository: repository,
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('策略').last);
    await tester.pumpAndSettle();
    await tester.drag(find.byType(ListView), const Offset(0, -1500));
    await tester.pumpAndSettle();
    await tester.tap(find.text('观察模式'));
    await tester.pumpAndSettle();

    expect(repository.selectedAutonomyLevel, 'OBSERVE');
    expect(find.text('当前'), findsOneWidget);
    expect(find.text('已切换到观察模式'), findsOneWidget);

    await tester.tap(find.text('完全访问'));
    await tester.pumpAndSettle();
    expect(find.text('开启完全访问？'), findsOneWidget);
    expect(find.text('Safety、设备在线检查、能力校验和执行回读仍然有效。'), findsOneWidget);
    await tester.tap(find.text('取消'));
    await tester.pumpAndSettle();
    expect(repository.selectedAutonomyLevel, 'OBSERVE');

    await tester.tap(find.text('完全访问'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('开启完全访问'));
    await tester.pumpAndSettle();
    expect(repository.selectedAutonomyLevel, 'AUTO');
    expect(find.text('完全访问'), findsWidgets);
  });
}
